Print Top at 101 %
Print the bottom at 100 %
Add two angle brackets as spacers below the USB-C breakout and use M2 nuts+bolts for the angle brackets to the case top
Use two small clamps on the other side to hold the LCD down

