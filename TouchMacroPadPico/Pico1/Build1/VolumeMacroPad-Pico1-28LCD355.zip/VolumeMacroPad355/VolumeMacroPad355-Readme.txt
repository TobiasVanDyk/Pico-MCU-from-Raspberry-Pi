Compiled with Pico SDK 2.12 dev, Arduino Pico 4.6.0 and included Adafruit_TinyUSB_Arduino 3.4.4, and TFTeSPI 2.5.43 (note comment below)
Pico 1 RP2040 and Waveshare ST7789 2.8 inch 320x240 LCD https://www.waveshare.com/pico-restouch-lcd-2.8.htm

Note: ST7789 LCD Macropad and TFT_eSP V2.5.43 fix: To obtain a working Touch-Macropad for the the Waveshare IPS ST7789 LCD Pico Board 320x240 2.8 inch using Bodmer TFT_eSPI version 2.5.43 replace the file Processors/TFT_eSPI_RP2040.h with the same file from the previous version V2.5.34.
-------------------------------------------------------------------------------------------------------------------------------------------------
Using library Adafruit_TinyUSB_Arduino at version 3.4.4 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0\libraries\Adafruit_TinyUSB_Arduino 
Using library SPI at version 1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0\libraries\SPI 
Using library TFT_eSPI at version 2.5.43 in folder: C:\Users\Tobias\Documents\Arduino\libraries\TFT_eSPI 
Using library LittleFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0\libraries\LittleFS 
Using library SDFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0\libraries\SDFS 
Using library SdFat at version 2.3.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0\libraries\SdFat 
Using library Time at version 1.6.1 in folder: C:\Users\Tobias\Documents\Arduino\libraries\Time 
"C:\\Users\\Tobias\\AppData\\Local\\Arduino15\\packages\\rp2040\\tools\\pqt-gcc\\4.1.0-1aec55e/bin/arm-none-eabi-size" -A "I:\\Data\\Win10\\Arduino/VolumeMacroPad355.ino.elf"
Sketch uses 250080 bytes (23%) of program storage space. Maximum is 1044480 bytes.
Global variables use 38324 bytes (14%) of dynamic memory, leaving 223820 bytes for local variables. Maximum is 262144 bytes.
C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\tools\pqt-python3\1.0.1-base-3a57aed-1/python3 -I C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.6.0/tools/uf2conv.py --serial COM4 --family RP2040 --deploy I:\Data\Win10\Arduino/VolumeMacroPad355.ino.uf2 
Resetting COM4
Converting to uf2, output size: 546816, start address: 0x2000
Scanning for RP2040 devices
Flashing D: (RPI-RP2)
Wrote 546816 bytes to D:/NEW.UF2
----------------------------------------------------------------------------------------------------------------

To install new version of Arduino Pico first delete it from boards manager, then delete the folder 
C:\Users\Name\AppData\Local\Arduino15\packages\rp2040 then close and reopen Arduino IDE and then add the new Arduino Pico Board again.
If a different display is used the Arduino-Pico build code must be deleted before building the new TFT_eSPI build.

NB: Use 2MB Flash option with 1MB Sketch 1 MB FS 
    Use USB Stack Adafruit TinyUSB
    Use 200MHz CPU 

New changes:
1. *vx*000 to *vx*111 Volume enabled/disabled in Layouts 1,3,4 if enabled in Layout 2 
2. *dt*f,m,s or *dt*0,1,2 to adjust the delay times between macros/keys-pressed for slower or virtual machines, medium fast PCs and fast PCs.
3. Default is now long-press Volume Mute off i.e. now L1-L4 and not V1-V4 default.
4. Increased delay times in DoPowerKeys because in VM or slower PC first characters are missing in restart or shutdown string.
5. Switch Backlight Off/On via *Cmd *bl*0 = off *bl*1 = on - can use serial monitor and send <*bl*0> for blankscreen and
    <*bl*1> for full bright screen. For inbetween values use *bl*nn nn = 00 - 99

Previous changes:
0. Made changes to CapNumScrollLock handling
1. Added Layout, Layer, and storage changes  via starcodes *ad*, *ae*, and *lx* - also via serial <*ad* > <*ae* > <*lx* >
See manual.h section (L)
2. Change logic in custom label setting - if a filename is added after *lm,s,t* then the result is the custom label enable is 
always ON
3. Added File Copy via starcode *cf*source=destination, copy file or /folder/file named in source to file or /folder/file
named in destination. *cf*0 or *cf*00 -> Copy all six default label files from SDCard to Flash, *cf*1 or *cf*01 is Flash to 
SDCard. For control via serial terminal use <*cf*source=destination>.
4. Bold Key Label Font now FreeSansBold11pt7b i.e. one point smaller.
5. (Different) custom label files can be on both Flash and SDCard FS. When the [Cfg][Opt]Custom-Label is used it will toggle
the SDCard option on/off if A-D is brown, and the Flash FS option on/off if A-D is white. 
6. Add custom labels up to five characters for keys M1-M24, S1-S24, T1-T24. Keys M, S, T 1-24 in Layouts 1, 3, and 4, 
can have descriptive and easily changeable, 5-character-maximum-length, labels. All the custom label definition files are 
saved on the SDCard through the content in files LabelM, LabelS, and LabelT, which contain the path i.e. /folder/filename 
of the file that has the custom key labels. By default these files are named label1, label2, and label3. Refer to the manual 
section (K) for more details.
7. Fixed Config80 arrangement when using strcpy()

