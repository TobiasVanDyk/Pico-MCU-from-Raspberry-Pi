Compiled with Pico SDK 2.21-develop, Arduino Pico 5.4.1 and included Adafruit_TinyUSB_Arduino 3.7.2, and TFTeSPI 2.5.43
Pico 1 RP2040 and Waveshare LCD Type C (125MHz) with SDCard module https://www.waveshare.com/3.5inch-rpi-lcd-c.htm
-------------------------------------------------------------------------------------------------------------------------------------------------
Using library Adafruit_TinyUSB_Arduino at version 3.7.2 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\5.4.1\libraries\Adafruit_TinyUSB_Arduino 
Using library SPI at version 1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\5.4.1\libraries\SPI 
Using library TFT_eSPI at version 2.5.43 in folder: C:\Users\Tobias\Documents\Arduino\libraries\TFT_eSPI 
Using library LittleFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\5.4.1\libraries\LittleFS 
Using library SDFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\5.4.1\libraries\SDFS 
Using library SdFat at version 2.3.1 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\5.4.1\libraries\SdFat 
"C:\\Users\\Tobias\\AppData\\Local\\Arduino15\\packages\\rp2040\\tools\\pqt-gcc\\4.1.0-1aec55e/bin/arm-none-eabi-size" -A "I:\\Data\\Win10\\Arduino/VolumeMacroPad292.ino.elf"
Sketch uses 243428 bytes (23%) of program storage space. Maximum is 1044480 bytes.
Global variables use 45632 bytes (17%) of dynamic memory, leaving 216512 bytes for local variables. Maximum is 262144 bytes.
Resetting COM3
Converting to uf2, output size: 546816, start address: 0x2000
Scanning for RP2040 devices
Flashing D: (RPI-RP2)
Wrote 546816 bytes to D:/NEW.UF2
----------------------------------------------------------------------------------------------------------------

To install new version of Arduino Pico first delete it from boards manager, then delete the folder 
C:\Users\Name\AppData\Local\Arduino15\packages\rp2040 then close and reopen Arduino IDE and then add the new Arduino Pico Board again.
If a different display is used the Arduino-Pico build code must be deleted before building the new TFT_eSPI build.

NB: Use 2MB Flash option with 1MB Sketch 1 MB FS 
    Use USB Stack Adafruit TinyUSB
    Use 200 or 125 MHz CPU when higher SPI read is used:  #define SPI_FREQUENCY      35000000  // 50MHz causes volume artifacts
                                                          #define SPI_READ_FREQUENCY 15000000  // 20 MHz also ok

New changes:
1. Completed all NumKey (option instead of nKeys) key values - use *09* to switch between nKeys and NumKeys. Fixed minor problems.
2. Fix PadKey status message for MouseKeys, SymbolsPages, MacroEditor, and fix Src Dst left in display if MacroKbrd not cancelled
3. Fix Black Text label on Black Key unreadable
4. Can now use up to 1080 Special Symbols (Math and Greek etc). 
   These symbols using 4-char Unicode and Alt+X expanded to up to 10 different symbol sets, each with 108 symbols (4 pages of 9 keys each with 3 symbols = 4 x 9 x 3 = 108.
   Load symbol set 0-9 using *ma*0-9 or by using the [Load] key in the Symbols page - if the file Math0 to Math9 exists on the SDCard it is loaded as the current symbol set.
   Read mathKeys.h for more instructions - you can use *ma* with no number added to save the 3 Math Arrays in mathKeys.h to the SDCard as file MathX
   The Symbols keys can now have up to 5 character labels (previously 3). 
5. Fixed Media Controls precedence and new options for media *e0* to *e6*

Previous changes:
1. *vx*000 to *vx*111 Volume enabled/disabled in Layouts 1,3,4 if enabled in Layout 2 
2. *dt*f,m,s or *dt*0,1,2 to adjust the delay times between macros/keys-pressed for slower or virtual machines, medium fast PCs and fast PCs.
3. Default is now long-press Volume Mute off i.e. now L1-L4 and not V1-V4 default.
4. Increased delay times in DoPowerKeys because in VM or slower PC first characters are missing in restart or shutdown string.
5. Switch Backlight Off/On via *Cmd *bl*0 = off *bl*1 = on - can use serial monitor and send <*bl*0> for blankscreen and
    <*bl*1> for full bright screen. For inbetween values use *bl*nn nn = 00 - 99







