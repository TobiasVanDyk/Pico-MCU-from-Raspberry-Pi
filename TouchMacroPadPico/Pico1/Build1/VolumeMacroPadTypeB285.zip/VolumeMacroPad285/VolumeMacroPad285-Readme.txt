Compiled with Pico SDK 2.12 dev, Arduino Pico 4.5.3 and included Adafruit_TinyUSB_Arduino 3.4.4, and TFTeSPI 2.5.43
Pico 1 RP2040 and RPi TouchLCD 3.5 inch Type B with an SDCard SPI reader module added https://www.waveshare.com/product/3.5inch-RPi-LCD-B.htm
-------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------------

To install new version of Arduino Pico first delete it from boards manager, then delete the folder 
C:\Users\Name\AppData\Local\Arduino15\packages\rp2040 then close and reopen Arduino IDE and then add the new Arduino Pico Board again.
If a different display is used the Arduino-Pico build code must be deleted before building the new TFT_eSPI build.

NB: Use 2MB Flash option with 1MB Sketch 1 MB FS 
    Use USB Stack Adafruit TinyUSB
    Use 200 or 125 MHz CPU when higher SPI read is used:  #define SPI_FREQUENCY      35000000  // 50MHz causes volume artifacts
                                                          #define SPI_READ_FREQUENCY 15000000  // 20 MHz also ok

New changes:
0. Made changes to CapNumScrollLock handling
1. 5 Pads 50% bigger and increased space between Pads and Keys
2. Added Layout, Layer, and storage changes  via starcodes *ad*, *ae*, and *lx* - also via serial <*ad* > <*ae* > <*lx* >
See manual.h section (L)
2. Added File Copy via starcode *cf*source=destination, copy file or /folder/file named in source to file or /folder/file
named in destination. *cf*0 or *cf*00 -> Copy all six default label files from SDCard to Flash, *cf*1 or *cf*01 is Flash to 
SDCard. For control via serial terminal use <*cf*source=destination>.

Previous changes:
1. Change logic in custom label setting - if a filename is added after *lm,s,t* then the result is the custom label enable is 
always ON
2. (Different) custom label files can be on both Flash and SDCard FS. When the [Cfg][Opt]Custom-Label is used it will toggle
the SDCard option on/off if A-D is brown, and the Flash FS option on/off if A-D is white. 
3. Add custom labels up to five characters for keys M1-M24, S1-S24, T1-T24. Keys M, S, T 1-24 in Layouts 1, 3, and 4, 
can have descriptive and easily changeable, 5-character-maximum-length, labels. All the custom label definition files are 
saved on the SDCard through the content in files LabelM, LabelS, and LabelT, which contain the path i.e. /folder/filename 
of the file that has the custom key labels. By default these files are named label1, label2, and label3. Refer to the manual 
section (K) for more details.
4. Fixed Config80 arrangement when using strcpy()




