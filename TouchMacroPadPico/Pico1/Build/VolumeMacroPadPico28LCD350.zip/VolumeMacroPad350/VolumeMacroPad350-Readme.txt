Compiled with Pico SDK 2.12 dev, Arduino Pico 4.5.3 and included Adafruit_TinyUSB_Arduino 3.4.4, and TFTeSPI 2.5.43 (note comment below)
Pico 1 RP2040 and Waveshare ST7789 2.8 inch 320x240 LCD https://www.waveshare.com/pico-restouch-lcd-2.8.htm

Note: ST7789 LCD Macropad and TFT_eSP V2.5.43 fix: To obtain a working Touch-Macropad for the the Waveshare IPS ST7789 LCD Pico Board 320x240 2.8 inch using Bodmer TFT_eSPI version 2.5.43 replace the file Processors/TFT_eSPI_RP2040.h with the same file from the previous version V2.5.34.
-------------------------------------------------------------------------------------------------------------------------------------------------
Using library Adafruit_TinyUSB_Arduino at version 3.4.4 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3\libraries\Adafruit_TinyUSB_Arduino 
Using library SPI at version 1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3\libraries\SPI 
Using library TFT_eSPI at version 2.5.43 in folder: C:\Users\Tobias\Documents\Arduino\libraries\TFT_eSPI 
Using library LittleFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3\libraries\LittleFS 
Using library SDFS at version 0.1.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3\libraries\SDFS 
Using library SdFat at version 2.3.0 in folder: C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3\libraries\SdFat 
Using library Time at version 1.6.1 in folder: C:\Users\Tobias\Documents\Arduino\libraries\Time 
"C:\\Users\\Tobias\\AppData\\Local\\Arduino15\\packages\\rp2040\\tools\\pqt-gcc\\4.0.1-8ec9d6f/bin/arm-none-eabi-size" -A "I:\\Data\\Win10\\Arduino/VolumeMacroPad350.ino.elf"
Sketch uses 250612 bytes (23%) of program storage space. Maximum is 1044480 bytes.
Global variables use 38308 bytes (14%) of dynamic memory, leaving 223836 bytes for local variables. Maximum is 262144 bytes.
C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\tools\pqt-python3\1.0.1-base-3a57aed-1/python3 -I C:\Users\Tobias\AppData\Local\Arduino15\packages\rp2040\hardware\rp2040\4.5.3/tools/uf2conv.py --serial COM5 --family RP2040 --deploy I:\Data\Win10\Arduino/VolumeMacroPad350.ino.uf2 
Resetting COM5
Converting to uf2, output size: 547328, start address: 0x2000
Scanning for RP2040 devices
Flashing D: (RPI-RP2)
Wrote 547328 bytes to D:/NEW.UF2
----------------------------------------------------------------------------------------------------------------

To install new version of Arduino Pico first delete it from boards manager, then delete the folder 
C:\Users\Name\AppData\Local\Arduino15\packages\rp2040 then close and reopen Arduino IDE and then add the new Arduino Pico Board again.
If a different display is used the Arduino-Pico build code must be deleted before building the new TFT_eSPI build.

NB: Use 4MB Flash option with 2MB Sketch 2MB FS 
    Use USB Stack Adafruit TinyUSB
    Use 150 MHz CPU:  #define SPI_TOUCH_FREQUENCY  1000000
                      #define SPI_READ_FREQUENCY   15000000
                      #define SPI_FREQUENCY        35000000 

New changes:
1. Add custom labels up to five characters for keys M1-M24, S1-S24, T1-T24. Keys M, S, T 1-24 in Layouts 1, 3, and 4, 
can have descriptive and easily changeable, 5-character-maximum-length, labels. All the custom label definition files are 
saved on the SDCard through the content in files LabelM, LabelS, and LabelT, which contain the path i.e. /folder/filename 
of the file that has the custom key labels. By default these files are named label1, label2, and label3. Refer to the manual 
section (K) for more details.
2. Fixed Config80 arrangement when using strcpy()
