/////////////
// sdcard.h
/////////////

File SDFile;                       // File object instance
byte SDByte;                       // Byte from File read from SDCard
byte SDNum = 1;                    // 1,2,3,4,5 - Select between 5 groups of 24 files on SDCard with size limited to its GB capacity. 
                                   // SDnum=0 => SDCard file read disabled
byte SDCardArr[4] = {1,0,0,0};     // Store/Retrieve SDnum + later expansion
char SDName [24][10];              // Current Filename choice - see comments below other ways to do this
                                   // 24 * (10 + 7 + 3 + 4 + 4) = 672 bytes
static const char SDName1 [24][10] = { "S0001.txt", "S0002.txt", "S0003.txt", "S0004.txt", "S0005.txt", "S0006.txt", 
                                       "S0007.txt", "S0008.txt", "S0009.txt", "S0010.txt", "S0011.txt", "S0012.txt", 
                                       "S0013.txt", "S0014.txt", "S0015.txt", "S0016.txt", "S0017.txt", "S0018.txt", 
                                       "S0019.txt", "S0020.txt", "S0021.txt", "S0022.txt", "S0023.txt", "S0024.txt" }; 
static const char SDName2 [24][7]  = { "A0.txt", "A1.txt", "A2.txt", "A3.txt", "A4.txt", "A5.txt", 
                                       "A6.txt", "A7.txt", "A8.txt", "A9.txt", "AA.txt", "AB.txt", 
                                       "AC.txt", "AD.txt", "AE.txt", "AF.txt", "B0.txt", "B1.txt", 
                                       "B2.txt", "B3.txt", "B4.txt", "B5.txt", "B6.txt", "B8.txt" };   
static const char SDName3 [24][3]  = { "01", "02", "03", "04", "05", "06", 
                                       "07", "08", "09", "10", "11", "12", 
                                       "13", "14", "15", "16", "17", "18", 
                                       "19", "20", "21", "22", "23", "24" };
static const char SDName4 [24][4]  = { "F01", "F02", "F03", "F04", "F05", "F06", 
                                       "F07", "F08", "F09", "F10", "F11", "F12", 
                                       "F13", "F14", "F15", "F16", "F17", "F18", 
                                       "F19", "F20", "F21", "F22", "F23", "F24" };
static const char SDName5 [24][4]  = { "X01", "X02", "X03", "X04", "X05", "X06", 
                                       "X07", "X08", "X09", "X10", "X11", "X12", 
                                       "X13", "X14", "X15", "X16", "X17", "X18", 
                                       "X19", "X20", "X21", "X22", "X23", "X24" };
                                       
/**********************************************************************************************************************************************
(1) Could program filenames based on a template such as S + 00 + nn + .txt
(2) Could use a single long character string instead of 24 separate strings, and then index into the long string using the size of the filename.
(3) If all filenames had the same (maximum) length could use a struct ( SDName1,...,SDName2 } equal-sized arrays + use pointers to index each set.
(4) Could use a combination of a struct and a union for (3) above i.e.
    struct sd  { char[m][n]SDName1,....,char[m][n]SDName5} }; struct sdindex { byte sd1[m x n],...,byte sd5[m x n] };
    union { sd sdnames; sdindex sdi } SDName; provided compiler padding rules are known.
***********************************************************************************************************************************************/
                                      
