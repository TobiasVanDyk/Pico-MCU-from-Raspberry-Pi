//////////////////////////////////////////////////////////////////////////////////////////
// sdcard.h
//////////////////////////////////////////////////////////////////////////////////////////
// Size = 24x10 * 2 + 24x7 + 24x3 = 720 bytes
//////////////////////////////////////////////////////////////////////////////////////////
// SD Filenames not case sensitive but are case preserving
// LittleFS Filenames are case sensitive
//
// Could therefore use STRname, MTRname, TTRname instead of SDNameS SDNameM SDNameT 
//////////////////////////////////////////////////////////////////////////////////////////

File SDFile;                       // File object instance
byte SDByte;                       // Byte from File read from SDCard
byte SDNum = 1;                    // 1 - 9 or k,K,M,S,T - Select between 9 + 5 groups of 24 files on SDCard with size limited to its GB capacity 
                                   // SDnum=0 => SDCard file read disabled
byte SDCardArr[4] = {1,0,0,0};     // [0] Store/Retrieve SDnum  [1] = char 0 = " ", 1-3, 4-9 = U V W X Y Z, k K m s t
char SDName [24][10];              // Current Filename choice - see comments below other ways to do this
                                   // 24 * (10 + 10 + 7 + 3) = 720 bytes - other names are constructed
static const char SDName1 [24][10] = { "S0001.txt", "S0002.txt", "S0003.txt", "S0004.txt", "S0005.txt", "S0006.txt", 
                                       "S0007.txt", "S0008.txt", "S0009.txt", "S0010.txt", "S0011.txt", "S0012.txt", 
                                       "S0013.txt", "S0014.txt", "S0015.txt", "S0016.txt", "S0017.txt", "S0018.txt", 
                                       "S0019.txt", "S0020.txt", "S0021.txt", "S0022.txt", "S0023.txt", "S0024.txt" }; 
static const char SDName2 [24][7]  = { "A1.txt", "A2.txt", "A3.txt", "A4.txt", "A5.txt", "A6.txt", 
                                       "B1.txt", "B2.txt", "B3.txt", "B4.txt", "B5.txt", "B6.txt", 
                                       "C1.txt", "C2.txt", "C3.txt", "C4.txt", "C5.txt", "C6.txt", 
                                       "D1.txt", "D2.txt", "D3.txt", "D4.txt", "D5.txt", "D6.txt" };   
static const char SDName3 [24][3]  = { "01", "02", "03", "04", "05", "06", 
                                       "07", "08", "09", "10", "11", "12", 
                                       "13", "14", "15", "16", "17", "18", 
                                       "19", "20", "21", "22", "23", "24" };
                                       
/////////////////////////////////////// SDNames 4-9 are computed as U01-Z01 to U24-Z24
/////////////////////////////////////// SDNames k,K,M,S,T are computed as K01 K01Link m01 s01 t01 to K24 K6Link 24K m24 s24 t24                                       

                                      
                                      
                                      
