////////////////
// strings24.h
////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Escape sequences \\ = backslash \? = ? \t = tab \b = backspace \" or \'  \x0A = hexadecimal number (byte)
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
char str1[] = "1";
char str2[] = "12";
char str3[] = "123";                            
char str4[] = "1234";
char str5[] = "C:\\Program Files (x86)\\SyncFolders\\SyncFolders.exe\r";   
char str6[] = "\n\r"; 
char str7[] = "cmd\r";                             
char str8[] = "winver\n";  
char str9[] = "cmd";
char str10[] = "Dism /Online /Cleanup-Image /RestoreHealth"; 
char str11[] = "Dism.exe /online /Cleanup-Image /StartComponentCleanup";                             
char str12[] = "Dism.exe /online /Cleanup-Image /StartComponentCleanup /ResetBase"; 
char str13[] = " ";
char str14[] = "    ";
char str15[] = "@gmail.com";                            
char str16[] = "@outlook.com";
char str17[] = "sfc /scannow\n";  
char str18[] = "\n\r"; 
char str19[] = "cmd\r";                             
char str20[] = "winver\n";  
char str21[] = "cmd";
char str22[] = "Dism /Online /Cleanup-Image /RestoreHealth"; 
char str23[] = "Dism.exe /online /Cleanup-Image /StartComponentCleanup";                             
char str24[] = "Dism.exe /online /Cleanup-Image /StartComponentCleanup /ResetBase"; 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Ctrl + Escape              - Open Start Menu
// GUI + Ctrl + Shft + B      - Wake PC from black or blank screen:
// GUI + X                    - Windows shutdown options
// GUI + Number               - Run Taskbar pinned item 1,2,3 etc.
// Ctrl + Shft + Escape       - open Task Manager
// Ctrl + Shft + N            - create new Folder
// GUI + Shift + S            - Snipping Tool
// GUI + V                    - Clipboard window
// GUI + I                    - open Settings
// AltL + ShftL + Numlock     - Mouse Keys on/off
// Shft 5 times               - Sticky Keys on/off
// Numlock 5 times            - Toggle Keys on/off
// ShftR 8 times              - Filter Keys on/off
// GUI + Ctrl + O             - On-Screen Keyboard
// Shift + F10                - Menu (Mouse Right-click)
// GUI + . or GUI + ;         - Emoji and (some) Math Symbols (click on Omega) insert
// Alt + NumPad Number        - special symbols math characters etc - Numlock must be on Alt+3 Alt+24 Alt+8733 Alt+10102
// Number + Alt+X             - Special symbols
// GUI + R                    - Character Map
// GUI + Space                - Choose Key Layout
// F11                        - Browser Fullscreen
// A combination: https://www.tindie.com/products/dekuNukem/duckypad-do-it-all-mechanical-macropad/
// GUI + R + notepad + C/R + Hello World + Ctrl + (repeat 10x) - Open Notepad insert Hello World make it bigger 10 x
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
